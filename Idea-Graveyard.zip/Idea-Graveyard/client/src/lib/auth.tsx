import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

interface AuthContextType {
  isAuthenticated: boolean;
  authToken: string | null;
  login: (password: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const AUTH_KEY = "teen_tabahi_auth";
const TOKEN_KEY = "teen_tabahi_token";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);

  useEffect(() => {
    const saved = sessionStorage.getItem(AUTH_KEY);
    const savedToken = sessionStorage.getItem(TOKEN_KEY);
    if (saved === "true" && savedToken) {
      setIsAuthenticated(true);
      setAuthToken(savedToken);
    }
  }, []);

  const login = async (password: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/auth/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await response.json();
      if (data.success && data.token) {
        setIsAuthenticated(true);
        setAuthToken(data.token);
        sessionStorage.setItem(AUTH_KEY, "true");
        sessionStorage.setItem(TOKEN_KEY, data.token);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = async () => {
    try {
      if (authToken) {
        await fetch("/api/auth/logout", {
          method: "POST",
          headers: { 
            "Content-Type": "application/json",
            "x-auth-token": authToken,
          },
        });
      }
    } catch {
      // Ignore logout errors
    }
    setIsAuthenticated(false);
    setAuthToken(null);
    sessionStorage.removeItem(AUTH_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, authToken, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
