import { motion } from "framer-motion";
import { Skull, Lightbulb, TrendingDown, Trophy, User } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Idea } from "@shared/schema";
import { FRIEND_NAMES, DROP_STAGES } from "@shared/schema";

interface StatsDashboardProps {
  ideas: Idea[];
}

export function StatsDashboard({ ideas }: StatsDashboardProps) {
  const totalIdeas = ideas.length;
  const droppedIdeas = ideas.filter(i => i.currentStage === "Dropped").length;
  const activeIdeas = totalIdeas - droppedIdeas;

  // Ideas per person
  const ideasByPerson = FRIEND_NAMES.map(name => ({
    name,
    total: ideas.filter(i => i.owner === name).length,
    dropped: ideas.filter(i => i.owner === name && i.currentStage === "Dropped").length,
  }));

  // Most dropped stage
  const dropStageCounts = DROP_STAGES.reduce((acc, stage) => {
    acc[stage] = ideas.filter(i => i.dropStage === stage).length;
    return acc;
  }, {} as Record<string, number>);

  const mostDeadlyStage = Object.entries(dropStageCounts)
    .sort(([, a], [, b]) => b - a)[0];

  // Biggest dropper
  const biggestDropper = [...ideasByPerson].sort((a, b) => b.dropped - a.dropped)[0];

  // Survival rate
  const survivalRate = totalIdeas > 0 ? Math.round((activeIdeas / totalIdeas) * 100) : 0;

  const getRoastForSurvival = (rate: number) => {
    if (rate === 100) return "Koi idea drop nahi? Suspicious...";
    if (rate >= 80) return "Impressive, lekin kitne ideas actually progress kar rahe?";
    if (rate >= 50) return "Half-half. Perfectly balanced, as all things should be.";
    if (rate >= 30) return "Idea graveyard filling up nicely!";
    return "Bhai, execution ke naam pe zero.";
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Trophy className="h-5 w-5 text-accent" />
        <h2 className="font-heading text-xl font-bold text-foreground">
          Roast Stats
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Ideas
              </CardTitle>
              <Lightbulb className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold font-heading">{totalIdeas}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {activeIdeas} alive, {droppedIdeas} dead
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Survival Rate
              </CardTitle>
              <TrendingDown className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold font-heading">{survivalRate}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                {getRoastForSurvival(survivalRate)}
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Deadliest Stage
              </CardTitle>
              <Skull className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold font-heading truncate">
                {mostDeadlyStage && mostDeadlyStage[1] > 0 
                  ? mostDeadlyStage[0].replace(" drop", "")
                  : "N/A"}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {mostDeadlyStage && mostDeadlyStage[1] > 0 
                  ? `${mostDeadlyStage[1]} ideas died here`
                  : "No drops yet (suspicious)"}
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Biggest Dropper
              </CardTitle>
              <User className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-heading">
                {biggestDropper?.dropped > 0 ? biggestDropper.name : "N/A"}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {biggestDropper?.dropped > 0 
                  ? `${biggestDropper.dropped} ideas in the grave`
                  : "Everyone's equally uncommitted"}
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {totalIdeas > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Ideas by Person
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                {ideasByPerson.map((person) => (
                  <div key={person.name} className="text-center">
                    <div className="text-2xl font-bold font-heading text-foreground">
                      {person.total}
                    </div>
                    <div className="text-sm font-medium text-foreground">
                      {person.name}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {person.dropped} dropped
                    </div>
                    {person.total > 0 && (
                      <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-destructive transition-all"
                          style={{ width: `${(person.dropped / person.total) * 100}%` }}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
