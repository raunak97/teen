import { format } from "date-fns";
import { motion } from "framer-motion";
import { Edit2, Skull, Lightbulb, Search, Hammer, Rocket, Star, Calendar, User } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Idea, IdeaStage } from "@shared/schema";

interface IdeaCardProps {
  idea: Idea;
  onEdit: (idea: Idea) => void;
  index: number;
}

const stageIcons: Record<IdeaStage, typeof Lightbulb> = {
  "Idea Stage": Lightbulb,
  "Research Stage": Search,
  "Initial Work Stage": Hammer,
  "Got Started Stage": Rocket,
  "Advanced Stage": Star,
  "Dropped": Skull,
};

const stageColors: Record<IdeaStage, string> = {
  "Idea Stage": "bg-amber-500/10 text-amber-600 dark:text-amber-400",
  "Research Stage": "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  "Initial Work Stage": "bg-purple-500/10 text-purple-600 dark:text-purple-400",
  "Got Started Stage": "bg-cyan-500/10 text-cyan-600 dark:text-cyan-400",
  "Advanced Stage": "bg-green-500/10 text-green-600 dark:text-green-400",
  "Dropped": "bg-red-500/10 text-red-600 dark:text-red-400",
};

const ownerColors: Record<string, string> = {
  "Raunak": "bg-primary/10 text-primary",
  "Sankalp": "bg-secondary/10 text-secondary",
  "Shivam": "bg-accent/10 text-accent",
};

export function IdeaCard({ idea, onEdit, index }: IdeaCardProps) {
  const stage = idea.currentStage as IdeaStage;
  const StageIcon = stageIcons[stage] || Lightbulb;
  const isDropped = stage === "Dropped";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <Card 
        className={`hover-elevate group ${isDropped ? "opacity-70" : ""}`}
        data-testid={`card-idea-${idea.id}`}
      >
        <CardContent className="p-4 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <h3 className={`font-heading font-semibold text-lg text-foreground truncate ${isDropped ? "line-through" : ""}`}>
                {idea.name}
              </h3>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
              onClick={() => onEdit(idea)}
              data-testid={`button-edit-idea-${idea.id}`}
            >
              <Edit2 className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Badge 
              variant="secondary" 
              className={`${stageColors[stage]} border-0`}
            >
              <StageIcon className="h-3 w-3 mr-1" />
              {stage}
            </Badge>
            <Badge 
              variant="secondary"
              className={`${ownerColors[idea.owner] || "bg-muted text-muted-foreground"} border-0`}
            >
              <User className="h-3 w-3 mr-1" />
              {idea.owner}
            </Badge>
          </div>

          {isDropped && idea.dropReason && (
            <div className="pt-2 border-t border-border">
              <p className="text-sm text-muted-foreground italic">
                "{idea.dropReason}"
              </p>
              {idea.dropStage && (
                <p className="text-xs text-muted-foreground mt-1">
                  Died at: {idea.dropStage}
                </p>
              )}
            </div>
          )}

          <div className="flex items-center gap-1 text-xs text-muted-foreground pt-1">
            <Calendar className="h-3 w-3" />
            <span>{format(new Date(idea.createdAt), "MMM d, yyyy")}</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
