import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Lightbulb, Skull, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { IDEA_STAGES, DROP_STAGES, FRIEND_NAMES, ROAST_MESSAGES, type Idea, type InsertIdea } from "@shared/schema";
import { RoastMessage } from "./roast-message";

const ideaFormSchema = z.object({
  name: z.string().min(1, "Idea ka naam to daal"),
  owner: z.enum(FRIEND_NAMES, { required_error: "Kiska idea hai bata" }),
  currentStage: z.enum(IDEA_STAGES),
  dropReason: z.string().optional(),
  dropStage: z.enum(DROP_STAGES).optional(),
}).refine((data) => {
  if (data.currentStage === "Dropped") {
    return data.dropReason && data.dropReason.length > 0 && data.dropStage;
  }
  return true;
}, {
  message: "Drop kiya to reason aur stage to batao",
  path: ["dropReason"],
});

type IdeaFormData = z.infer<typeof ideaFormSchema>;

interface IdeaFormProps {
  idea?: Idea | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: InsertIdea) => Promise<void>;
  onDelete?: (id: string) => Promise<void>;
  isSubmitting: boolean;
}

export function IdeaForm({ idea, isOpen, onClose, onSubmit, onDelete, isSubmitting }: IdeaFormProps) {
  const [showRoast, setShowRoast] = useState(false);
  const [roastMessage, setRoastMessage] = useState("");
  const [wasDropped, setWasDropped] = useState(false);

  const form = useForm<IdeaFormData>({
    resolver: zodResolver(ideaFormSchema),
    defaultValues: {
      name: "",
      owner: undefined,
      currentStage: "Idea Stage",
      dropReason: "",
      dropStage: undefined,
    },
  });

  const currentStage = form.watch("currentStage");
  const isDropped = currentStage === "Dropped";

  useEffect(() => {
    if (idea) {
      form.reset({
        name: idea.name,
        owner: idea.owner as typeof FRIEND_NAMES[number],
        currentStage: idea.currentStage as typeof IDEA_STAGES[number],
        dropReason: idea.dropReason || "",
        dropStage: idea.dropStage as typeof DROP_STAGES[number] | undefined,
      });
      setWasDropped(idea.currentStage === "Dropped");
    } else {
      form.reset({
        name: "",
        owner: undefined,
        currentStage: "Idea Stage",
        dropReason: "",
        dropStage: undefined,
      });
      setWasDropped(false);
    }
  }, [idea, form]);

  const handleSubmit = async (data: IdeaFormData) => {
    const submitData: InsertIdea = {
      name: data.name,
      owner: data.owner,
      currentStage: data.currentStage,
      dropReason: data.currentStage === "Dropped" ? data.dropReason : undefined,
      dropStage: data.currentStage === "Dropped" ? data.dropStage : undefined,
    };

    const justDropped = data.currentStage === "Dropped" && !wasDropped;

    await onSubmit(submitData);

    if (justDropped) {
      const randomRoast = ROAST_MESSAGES[Math.floor(Math.random() * ROAST_MESSAGES.length)];
      setRoastMessage(randomRoast);
      setShowRoast(true);
    }

    onClose();
  };

  const handleDelete = async () => {
    if (idea && onDelete) {
      await onDelete(idea.id);
      onClose();
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading flex items-center gap-2">
              {idea ? (
                <>
                  <Skull className="h-5 w-5 text-primary" />
                  Edit Idea
                </>
              ) : (
                <>
                  <Lightbulb className="h-5 w-5 text-primary" />
                  Naya Idea Add Kar
                </>
              )}
            </DialogTitle>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Idea Name</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Next billion dollar idea..."
                        data-testid="input-idea-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="owner"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Whose Idea?</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-owner">
                          <SelectValue placeholder="Kiska idea hai?" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {FRIEND_NAMES.map((name) => (
                          <SelectItem key={name} value={name} data-testid={`option-owner-${name}`}>
                            {name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="currentStage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Stage</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-stage">
                          <SelectValue placeholder="Stage select karo" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {IDEA_STAGES.map((stage) => (
                          <SelectItem key={stage} value={stage} data-testid={`option-stage-${stage}`}>
                            {stage}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {isDropped && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 pt-2 border-t border-border"
                >
                  <FormField
                    control={form.control}
                    name="dropStage"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>At Which Stage Did It Die?</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-drop-stage">
                              <SelectValue placeholder="Kahan pe mara?" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {DROP_STAGES.map((stage) => (
                              <SelectItem key={stage} value={stage} data-testid={`option-drop-${stage}`}>
                                {stage}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dropReason"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Why Did It Die?</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Kyun nahi hua? Sach bata..."
                            className="resize-none"
                            rows={3}
                            data-testid="input-drop-reason"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </motion.div>
              )}

              <div className="flex gap-2 pt-4">
                {idea && onDelete && (
                  <Button
                    type="button"
                    variant="destructive"
                    onClick={handleDelete}
                    disabled={isSubmitting}
                    data-testid="button-delete-idea"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                )}
                <div className="flex-1" />
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting} data-testid="button-save-idea">
                  <Save className="h-4 w-4 mr-2" />
                  {isSubmitting ? "Saving..." : "Save"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <RoastMessage
        message={roastMessage}
        isOpen={showRoast}
        onClose={() => setShowRoast(false)}
      />
    </>
  );
}
