import { motion, AnimatePresence } from "framer-motion";
import { Skull, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface RoastMessageProps {
  message: string;
  isOpen: boolean;
  onClose: () => void;
}

export function RoastMessage({ message, isOpen, onClose }: RoastMessageProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="bg-card border border-border rounded-lg p-8 max-w-md w-full text-center shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <motion.div
              animate={{ 
                rotate: [0, -10, 10, -10, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-destructive/10 mb-4"
            >
              <Skull className="w-8 h-8 text-destructive" />
            </motion.div>
            
            <h3 className="font-heading text-xl font-bold text-foreground mb-2">
              Idea Dropped!
            </h3>
            
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-lg text-muted-foreground mb-6 font-medium"
            >
              {message}
            </motion.p>

            <Button onClick={onClose} variant="outline" data-testid="button-close-roast">
              <X className="h-4 w-4 mr-2" />
              Okay, move on
            </Button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
