import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Plus, LogOut, Skull, Lightbulb, Search, Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { ThemeToggle } from "@/components/theme-toggle";
import { IdeaCard } from "@/components/idea-card";
import { IdeaForm } from "@/components/idea-form";
import { StatsDashboard } from "@/components/stats-dashboard";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Idea, InsertIdea, IdeaStage } from "@shared/schema";
import { IDEA_STAGES, FRIEND_NAMES } from "@shared/schema";

export default function DashboardPage() {
  const { logout } = useAuth();
  const { toast } = useToast();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingIdea, setEditingIdea] = useState<Idea | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [stageFilter, setStageFilter] = useState<string>("all");
  const [ownerFilter, setOwnerFilter] = useState<string>("all");

  const { data: ideas = [], isLoading } = useQuery<Idea[]>({
    queryKey: ["/api/ideas"],
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertIdea) => apiRequest("POST", "/api/ideas", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ideas"] });
      toast({ title: "Idea added!", description: "Ab execute kar le bhadwe" });
    },
    onError: () => {
      toast({ title: "Error", description: "Kuch toh gadbad hai", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertIdea }) => 
      apiRequest("PATCH", `/api/ideas/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ideas"] });
      toast({ title: "Updated!", description: "Changes saved" });
    },
    onError: () => {
      toast({ title: "Error", description: "Update fail ho gaya", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/ideas/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ideas"] });
      toast({ title: "Deleted!", description: "Idea permanently gone" });
    },
    onError: () => {
      toast({ title: "Error", description: "Delete fail ho gaya", variant: "destructive" });
    },
  });

  const handleSubmit = async (data: InsertIdea) => {
    if (editingIdea) {
      await updateMutation.mutateAsync({ id: editingIdea.id, data });
    } else {
      await createMutation.mutateAsync(data);
    }
    setEditingIdea(null);
  };

  const handleDelete = async (id: string) => {
    await deleteMutation.mutateAsync(id);
  };

  const handleEdit = (idea: Idea) => {
    setEditingIdea(idea);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingIdea(null);
  };

  const filteredIdeas = ideas.filter((idea) => {
    const matchesSearch = idea.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      idea.owner.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStage = stageFilter === "all" || idea.currentStage === stageFilter;
    const matchesOwner = ownerFilter === "all" || idea.owner === ownerFilter;
    return matchesSearch && matchesStage && matchesOwner;
  });

  const hasFilters = searchQuery || stageFilter !== "all" || ownerFilter !== "all";

  const clearFilters = () => {
    setSearchQuery("");
    setStageFilter("all");
    setOwnerFilter("all");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Skull className="h-6 w-6 text-primary" />
            <h1 className="font-heading text-xl font-bold text-foreground hidden sm:block">
              Teen Tabahi
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <Button
              onClick={() => setIsFormOpen(true)}
              data-testid="button-add-idea"
            >
              <Plus className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Naya Idea</span>
              <span className="sm:hidden">Add</span>
            </Button>
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              onClick={logout}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-2"
        >
          <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground">
            "Kuch Bana Le Bhadwe"
          </h2>
          <p className="text-muted-foreground">
            Track your ideas. Get roasted. Maybe execute one someday.
          </p>
        </motion.div>

        <StatsDashboard ideas={ideas} />

        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-accent" />
            <h2 className="font-heading text-xl font-bold text-foreground">
              All Ideas
            </h2>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search ideas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search"
              />
            </div>
            <div className="flex gap-2">
              <Select value={stageFilter} onValueChange={setStageFilter}>
                <SelectTrigger className="w-[140px]" data-testid="filter-stage">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Stage" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Stages</SelectItem>
                  {IDEA_STAGES.map((stage) => (
                    <SelectItem key={stage} value={stage}>
                      {stage}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={ownerFilter} onValueChange={setOwnerFilter}>
                <SelectTrigger className="w-[130px]" data-testid="filter-owner">
                  <SelectValue placeholder="Owner" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Friends</SelectItem>
                  {FRIEND_NAMES.map((name) => (
                    <SelectItem key={name} value={name}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {hasFilters && (
                <Button variant="ghost" size="icon" onClick={clearFilters} data-testid="button-clear-filters">
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-40 rounded-lg" />
              ))}
            </div>
          ) : filteredIdeas.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <Skull className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-heading text-lg font-semibold text-foreground mb-2">
                {ideas.length === 0 ? "No Ideas Yet" : "No Matching Ideas"}
              </h3>
              <p className="text-muted-foreground mb-4">
                {ideas.length === 0 
                  ? "Pehla idea add kar. Phir usse drop kar. Classic."
                  : "Try different filters or search terms"}
              </p>
              {ideas.length === 0 && (
                <Button onClick={() => setIsFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add First Idea
                </Button>
              )}
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredIdeas.map((idea, index) => (
                <IdeaCard
                  key={idea.id}
                  idea={idea}
                  onEdit={handleEdit}
                  index={index}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <IdeaForm
        idea={editingIdea}
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSubmit={handleSubmit}
        onDelete={handleDelete}
        isSubmitting={createMutation.isPending || updateMutation.isPending}
      />
    </div>
  );
}
