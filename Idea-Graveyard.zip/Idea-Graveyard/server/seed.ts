import { db } from "./db";
import { ideas } from "@shared/schema";
import { sql } from "drizzle-orm";

const sampleIdeas = [
  {
    name: "AI-powered chai ordering app",
    owner: "Raunak",
    currentStage: "Dropped",
    dropReason: "Market research showed everyone prefers calling the chai wala directly",
    dropStage: "Research stage drop",
  },
  {
    name: "Uber for parking spots",
    owner: "Sankalp",
    currentStage: "Initial Work Stage",
    dropReason: null,
    dropStage: null,
  },
  {
    name: "Dating app for people who hate dating apps",
    owner: "Shivam",
    currentStage: "Dropped",
    dropReason: "Realized the irony was too strong. Also no one wanted to join.",
    dropStage: "Idea stage drop",
  },
  {
    name: "Subscription box for random snacks",
    owner: "Raunak",
    currentStage: "Research Stage",
    dropReason: null,
    dropStage: null,
  },
  {
    name: "AI girlfriend but for debugging code",
    owner: "Sankalp",
    currentStage: "Dropped",
    dropReason: "GitHub Copilot exists. Also, creepy.",
    dropStage: "Research stage drop",
  },
  {
    name: "Social network for introverts",
    owner: "Shivam",
    currentStage: "Idea Stage",
    dropReason: null,
    dropStage: null,
  },
  {
    name: "NFT marketplace for memes",
    owner: "Raunak",
    currentStage: "Dropped",
    dropReason: "Market crashed. Bubble burst. Dreams shattered.",
    dropStage: "Got started stage drop",
  },
  {
    name: "Fitness app that roasts you",
    owner: "Sankalp",
    currentStage: "Got Started Stage",
    dropReason: null,
    dropStage: null,
  },
];

export async function seedDatabase() {
  try {
    const existingIdeas = await db.select({ count: sql<number>`count(*)` }).from(ideas);
    
    if (existingIdeas[0].count === 0) {
      console.log("Seeding database with sample ideas...");
      
      for (const idea of sampleIdeas) {
        await db.insert(ideas).values(idea);
      }
      
      console.log(`Seeded ${sampleIdeas.length} sample ideas`);
    } else {
      console.log("Database already has data, skipping seed");
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
