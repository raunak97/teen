import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertIdeaSchema, baseInsertIdeaSchema } from "@shared/schema";
import { z } from "zod";

const APP_PASSWORD = "Ankitlove";

// Simple session store for authenticated clients
const authenticatedSessions = new Set<string>();

// Generate a simple session token
function generateSessionToken(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

// Auth middleware - checks for valid session token
function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authToken = req.headers["x-auth-token"];
  
  if (!authToken || typeof authToken !== "string" || !authenticatedSessions.has(authToken)) {
    return res.status(401).json({ error: "Unauthorized. Please login first." });
  }
  
  next();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Password verification - returns a session token on success
  app.post("/api/auth/verify", async (req, res) => {
    const { password } = req.body;
    
    if (password === APP_PASSWORD) {
      const token = generateSessionToken();
      authenticatedSessions.add(token);
      res.json({ success: true, token });
    } else {
      res.json({ success: false });
    }
  });

  // Logout - invalidate session token
  app.post("/api/auth/logout", async (req, res) => {
    const authToken = req.headers["x-auth-token"];
    if (authToken && typeof authToken === "string") {
      authenticatedSessions.delete(authToken);
    }
    res.json({ success: true });
  });

  // All idea routes require authentication
  // Get all ideas
  app.get("/api/ideas", authMiddleware, async (_req, res) => {
    try {
      const ideas = await storage.getAllIdeas();
      res.json(ideas);
    } catch (error) {
      console.error("Error fetching ideas:", error);
      res.status(500).json({ error: "Failed to fetch ideas" });
    }
  });

  // Get single idea
  app.get("/api/ideas/:id", authMiddleware, async (req, res) => {
    try {
      const id = req.params.id as string;
      const idea = await storage.getIdea(id);
      if (!idea) {
        return res.status(404).json({ error: "Idea not found" });
      }
      res.json(idea);
    } catch (error) {
      console.error("Error fetching idea:", error);
      res.status(500).json({ error: "Failed to fetch idea" });
    }
  });

  // Create new idea
  app.post("/api/ideas", authMiddleware, async (req, res) => {
    try {
      const validatedData = insertIdeaSchema.parse(req.body);
      const idea = await storage.createIdea(validatedData);
      res.status(201).json(idea);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating idea:", error);
      res.status(500).json({ error: "Failed to create idea" });
    }
  });

  // Update idea
  app.patch("/api/ideas/:id", authMiddleware, async (req, res) => {
    try {
      // For updates, use the base schema partial
      const partialSchema = baseInsertIdeaSchema.partial();
      const validatedData = partialSchema.parse(req.body);
      
      // If updating to Dropped, ensure dropReason and dropStage are provided
      if (validatedData.currentStage === "Dropped") {
        if (!validatedData.dropReason || !validatedData.dropStage) {
          return res.status(400).json({ 
            error: "dropReason and dropStage are required when setting status to Dropped" 
          });
        }
      }
      
      const id = req.params.id as string;
      const idea = await storage.updateIdea(id, validatedData);
      if (!idea) {
        return res.status(404).json({ error: "Idea not found" });
      }
      res.json(idea);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error updating idea:", error);
      res.status(500).json({ error: "Failed to update idea" });
    }
  });

  // Delete idea
  app.delete("/api/ideas/:id", authMiddleware, async (req, res) => {
    try {
      const id = req.params.id as string;
      const deleted = await storage.deleteIdea(id);
      if (!deleted) {
        return res.status(404).json({ error: "Idea not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting idea:", error);
      res.status(500).json({ error: "Failed to delete idea" });
    }
  });

  return httpServer;
}
