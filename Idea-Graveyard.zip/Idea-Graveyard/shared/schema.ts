import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Idea stages
export const IDEA_STAGES = [
  "Idea Stage",
  "Research Stage",
  "Initial Work Stage",
  "Got Started Stage",
  "Advanced Stage",
  "Dropped"
] as const;

export type IdeaStage = typeof IDEA_STAGES[number];

// Drop stages (when idea is dropped, at which stage)
export const DROP_STAGES = [
  "Idea stage drop",
  "Research stage drop",
  "Initial work stage drop",
  "Got started stage drop",
  "Advanced stage drop"
] as const;

export type DropStage = typeof DROP_STAGES[number];

// Friend names for the app
export const FRIEND_NAMES = ["Raunak", "Sankalp", "Shivam"] as const;
export type FriendName = typeof FRIEND_NAMES[number];

// Ideas table
export const ideas = pgTable("ideas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  owner: text("owner").notNull(), // Raunak, Sankalp, or Shivam
  currentStage: text("current_stage").notNull().default("Idea Stage"),
  dropReason: text("drop_reason"), // Only filled if dropped
  dropStage: text("drop_stage"), // Only filled if dropped
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Base schema without refinement (for partial updates)
export const baseInsertIdeaSchema = createInsertSchema(ideas).omit({
  id: true,
  createdAt: true,
}).extend({
  name: z.string().min(1, "Idea name is required"),
  owner: z.enum(FRIEND_NAMES, { required_error: "Pick whose idea it is" }),
  currentStage: z.enum(IDEA_STAGES).default("Idea Stage"),
  dropReason: z.string().optional(),
  dropStage: z.enum(DROP_STAGES).optional(),
});

// Full schema with refinement (for creates)
export const insertIdeaSchema = baseInsertIdeaSchema.refine((data) => {
  if (data.currentStage === "Dropped") {
    return data.dropReason && data.dropReason.length > 0 && data.dropStage;
  }
  return true;
}, {
  message: "dropReason and dropStage are required when idea is Dropped",
  path: ["dropReason"],
});

export type InsertIdea = z.infer<typeof baseInsertIdeaSchema>;
export type Idea = typeof ideas.$inferSelect;

// Roast messages for dropped ideas (no emoji per design guidelines)
export const ROAST_MESSAGES = [
  "Aur ek idea gaya kabristan mein...",
  "Research tak gaya, execution se darr gaya?",
  "Bhai tu idea machine hai, builder nahi.",
  "Kuch to bana le bhadwe.",
  "Idea drop karne mein to Olympic gold le jaayega tu.",
  "Execution? Wo kya hota hai?",
  "Wapas discussion mode ON.",
  "Entrepreneurship ke naam pe sirf vibes.",
  "Idea RIP. Tera motivation bhi.",
  "Fir se 'next time pakka' incoming.",
  "Agle startup summit ke liye new idea chahiye?",
  "Consistency? We don't do that here.",
  "Aur ek sapna toota.",
  "This idea is now in permanent 'We'll see' mode.",
  "Tera idea history mein store ho gaya. Forever.",
];

// Users table (keeping for potential future use)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
